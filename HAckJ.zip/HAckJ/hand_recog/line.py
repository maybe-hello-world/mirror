# ---------------------------------------
# ATTENTION
# Some constants here

# filename of keras model
h5_model = 'hand_recog/model.h5'


counter = 0
# available hand poses
pose = [
	'down_arm',
	'elbov_down',
	'elbov_up',
	'on_us',
	't_arm',
	'up_arm'
]
# ---------------------------------------

import base64
import shutil
import tempfile

import cv2
import imutils
import keras.models
import numpy as np

# some matrix dims order problems
from keras import backend as K
from keras.preprocessing.image import img_to_array, load_img

K.set_image_dim_ordering('th')

# load model to memory
model = keras.models.load_model(h5_model)

# load classifier
lbp_face_cfr = cv2.CascadeClassifier('hand_recog/haar.xml')

# create temp dir
dirpath = tempfile.mkdtemp()


def __find_crop_area(image):
	faces = lbp_face_cfr.detectMultiScale(image, scaleFactor=1.1, minNeighbors=3)

	if len(faces) == 1:
		x, y, w, h = faces[0]
	elif len(faces) == 0:
		x = int(image.shape[1] // 2)
		w = int(image.shape[1] // 6)
		y = 0
		h = int(image.shape[0] // 6)
	else:
		# Find rectangle that is smallest and highest
		min_w = 10**6
		min_h = 10**6
		counter = 0
		ans = 0

		for (x, y, w, h) in faces:
			if w < min_w and h < min_h:
				ans = counter
				min_h = h
				min_w = w
			counter += 1

		x, y, w, h = faces[ans]

	# cut point
	cut_point_x = x + int(w // 2)
	cut_point_y = y - 2 * h

	if cut_point_y < 0:
		cut_point_y = 0

	x_start = cut_point_x - w * 4
	if x_start < 0:
		x_start = 0

	x_stop = cut_point_x

	y_start = cut_point_y
	y_stop = cut_point_y + 6 * h

	return x_start, x_stop, y_start, y_stop


def __b64toimg(uri):
	encoded_data = uri
	nparr = np.fromstring(base64.b64decode(encoded_data), np.uint8)
	img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
	return img


def __get_hand_images(image):
	# resize and convert to gray
	image = imutils.resize(image, width=min(400, image.shape[1]))
	image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

	# get human position to crop
	x_start, x_stop, y_start, y_stop = __find_crop_area(image)
	x_stop2 = 2 * x_stop - x_start
	if x_stop2 > image.shape[1]:
		x_stop2 = image.shape[1]

	# crop images
	image1 = image[y_start:y_stop, x_start:x_stop]
	image2 = cv2.flip(image[y_start:y_stop, x_stop:x_stop2], 1)
	del image

	# resize precisely
	image1 = imutils.resize(image1, width=34, height=51)
	if image1.shape[0] >= 48 and image1.shape[1] >= 32:
		image1 = image1[:48, :32]

	# and second
	image2 = imutils.resize(image2, width=34, height=51)
	if image2.shape[0] >= 48 and image2.shape[1] >= 32:
		image2 = image2[:48, :32]

	return image1, image2


def __get_prediction(image):
	# get image
	x = load_img(image, target_size=(32, 48))

	x = img_to_array(x)
	x = x.reshape((1,) + x.shape)

	# predict position
	result = model.predict(x)[0]
	res_class = int(np.argmax(result))
	return pose[res_class]


def get_hands(base64_image):
	global counter
	"""
	Do not forget to call 'finish' procedure before exiting of the whole project

	:param base64_image:
	:return:
	"""

	# Got base64 image -> convert to cv2.img
	image = __b64toimg(base64_image)
	del base64_image

	# get left and right body pictures
	image1, image2 = __get_hand_images(image)
	del image

	# shitcode here
	im1_name = dirpath + "left.jpg"
	im2_name = dirpath + "right.jpg"
	cv2.imwrite(im1_name, image1)
	cv2.imwrite(im2_name, image2)
	cv2.imwrite("image1_" + str(counter) + ".jpg", image1)
	cv2.imwrite("image2_" + str(counter) + ".jpg", image2)
	print("saved")
	counter += 1

	# get predictions for hands
	left_hand = __get_prediction(im1_name)
	right_hand = __get_prediction(im2_name)

	return left_hand, right_hand


def finish():
	"""
	Call me before finishing the whole program
	"""
	shutil.rmtree(dirpath)