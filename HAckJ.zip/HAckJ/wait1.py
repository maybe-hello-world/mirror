import json
import socket
import hand_recog

serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host = "192.168.4.110"
port = 5000
buffer_size = 4096*32

serverSocket.bind((host, port))
serverSocket.listen(10)
print("Starting server...")

while True:
	clientSocket, address = serverSocket.accept()
	print("Connection received from %s..." % str(address))

	lenn = clientSocket.recv(buffer_size)
	print(lenn)
	clientSocket.send(str.encode(json.dumps({"res": "ok"})))

	data = clientSocket.recv(buffer_size)
	# print(data)
	clientSocket.send(str.encode(json.dumps({"res": "ok"})))
	# print(lenn)
	rlenn = 0
	ddata = ""
	data = data.decode()
	try:
		while data.find("#end") == -1:
			# print("!")
			ddata += data
			data = clientSocket.recv(buffer_size)
			data = data.decode()
			# print(data)
			# jdata = json.loads(data)
			rlenn += buffer_size
			# print(rlenn)

		# clientSocket.send(str.encode(json.dumps({"res":"ok"})))
		clientSocket.send(str.encode("#complete"))

		# clientSocket.send(json.dumps({"someresult":"as"}))

		ddata += data[:data.find("#end")]
		# print(ddata)
		# print(len(ddata))
		# print(lenn)
		a, b = hand_recog.line.get_hands(ddata)
		clientSocket.send(str.encode(a + "~" + b))
		print(a + " " + b)
		data = clientSocket.recv(buffer_size)
		clientSocket.close()
		# with open("imageToSave.jpg", "wb") as fh:
		# 	fh.write(ddata.decode('base64'))
	except Exception as e:
		print("ERORRRRR" + e)
		clientSocket.close()
	finally:
		# clientSocket.close()
		pass
		# time.sleep(10)
	print("Next Term!")
#
# @app.route('/api/classify', methods=['POST'])
# def classify():
#     image_b64 = request.get_json()['image']
#     with open("imageToSave.jpg", "wb") as fh:
#         fh.write(image_b64.decode('base64'))
#     return jsonify("ok"), 200
# if __name__ == "__main__":
#     app.run(debug=True)
