sstr = "asd~aswq"

print(sstr[:sstr.find("~")])

print(sstr[sstr.find("~")+1:])

