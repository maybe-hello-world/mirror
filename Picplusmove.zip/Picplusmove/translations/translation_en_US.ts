<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>One</source>
            <comment>Text</comment>
            <translation type="obsolete">One</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Hello</source>
            <comment>Text</comment>
            <translation>Hello</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <source>Two</source>
            <comment>Text</comment>
            <translation type="obsolete">Two</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (2)</name>
        <message>
            <source>Three</source>
            <comment>Text</comment>
            <translation type="obsolete">Three</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (3)</name>
        <message>
            <source>4</source>
            <comment>Text</comment>
            <translation type="obsolete">4</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (4)</name>
        <message>
            <source>5</source>
            <comment>Text</comment>
            <translation type="obsolete">5</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (5)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>What did you said?</source>
            <comment>Text</comment>
            <translation type="obsolete">What did you said?</translation>
        </message>
        <message>
            <source>Whatdidyousaid</source>
            <comment>Text</comment>
            <translation type="obsolete">Whatdidyousaid</translation>
        </message>
        <message>
            <source>What</source>
            <comment>Text</comment>
            <translation type="obsolete">What</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Hey, i didn't understand you. Say it again!</source>
            <comment>Text</comment>
            <translation type="unfinished">Hey, i didn't understand you. Say it again!</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (6)</name>
        <message>
            <source>What</source>
            <comment>Text</comment>
            <translation type="obsolete">What</translation>
        </message>
        <message>
            <source>wrong</source>
            <comment>Text</comment>
            <translation type="obsolete">wrong</translation>
        </message>
        <message>
            <source>repeating you</source>
            <comment>Text</comment>
            <translation type="obsolete">repeating you</translation>
        </message>
    </context>
</TS>
